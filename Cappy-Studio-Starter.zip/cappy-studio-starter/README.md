# Cappy Studio — Free-first starter

A mobile-first starter inspired by the supplied Cappy Studio screenshots. It includes a responsive creator dashboard and a working Gemini-backed recap-script API. It is not yet a complete video rendering SaaS: real TTS, subtitle burn-in, FFmpeg rendering, authentication, billing/credits and secure per-user job history are planned integrations.

## 1) Run locally

1. Install Node.js 20+ on a computer, or use a browser IDE such as GitHub Codespaces from your phone.
2. Upload this project to a GitHub repository.
3. Copy `.env.example` to `.env.local` and set `GEMINI_API_KEY`.
4. Run `npm install` then `npm run dev`.
5. Open the preview URL.

## 2) Get a Gemini API key

Open https://aistudio.google.com/app/apikey and create an API key. Add it as `GEMINI_API_KEY` in Vercel Environment Variables (or `.env.local` locally). Never put this key in client-side code or commit it to GitHub. Check current model availability and free-tier quotas in Google AI Studio; free quotas can change and may vary by region/model.

## 3) Optional Supabase setup

1. Create a Supabase project at https://supabase.com.
2. In SQL Editor, run `supabase/schema.sql`.
3. Add `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY` to `.env.local` and Vercel.
4. The sample SQL includes intentionally permissive temporary policies for a private prototype. Do NOT launch publicly with these policies. Before public use, add Supabase Auth, an owner/user_id column, row-level policies restricting each user to their own jobs, private bucket policies, and upload size limits appropriate to your plan.

## 4) Deploy on Vercel

1. Push the project to GitHub.
2. Import the repository at https://vercel.com/new.
3. Add `GEMINI_API_KEY` and optional Supabase environment variables in Project Settings → Environment Variables.
4. Deploy. If you change environment variables, redeploy.

## 5) What works now

- Responsive mobile dashboard, platform selection, voice choice UI, speed and output settings.
- Movie/context prompt to Gemini and generated recap script display/copy.
- Optional upload to Supabase Storage when configured (prototype 50 MB bucket cap in sample SQL).
- Optional insertion of generated scripts into a Supabase table.

## 6) What is not implemented yet

- Actual AI voice synthesis: connect a TTS provider and generate audio from the script.
- Video timeline editing, automatic clip selection, subtitles rendered into MP4, transitions, thumbnail generation and final MP4 export: these need a separate background worker (for example a small FFmpeg worker on a supported host). Vercel serverless functions are not suitable for long-running video rendering.
- Login, secure credits, payment, admin panel and production-grade per-user data access.

## Copyright and safety

Only upload or process videos you own or have permission to use. A recap script should be original commentary, not a substitute for the movie or a reproduction of its dialogue. AI output can be inaccurate; review plot details before publishing.
