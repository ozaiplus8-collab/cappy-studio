-- Run this in Supabase SQL Editor.
create table if not exists public.recap_jobs (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  movie_title text not null,
  platform text not null default 'TikTok',
  language text not null default 'မြန်မာ',
  script text,
  status text not null default 'queued'
);

alter table public.recap_jobs enable row level security;
-- Starter policy for testing only. Replace with authenticated-user ownership policies before public launch.
create policy "temporary public insert jobs" on public.recap_jobs for insert to anon with check (true);

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('source-videos', 'source-videos', false, 52428800, array['video/mp4','video/quicktime','video/webm'])
on conflict (id) do nothing;

-- Temporary upload policy for prototype testing only. Add user folder ownership before public launch.
create policy "temporary anon upload" on storage.objects for insert to anon with check (bucket_id = 'source-videos');
