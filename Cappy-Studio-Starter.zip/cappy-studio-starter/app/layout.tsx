import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Cappy Studio — AI Recap Creator',
  description: 'Create movie recap scripts and prepare short-form videos.',
  viewport: 'width=device-width, initial-scale=1, maximum-scale=1'
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="my"><body>{children}</body></html>;
}
