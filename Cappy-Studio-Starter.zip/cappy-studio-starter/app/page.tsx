'use client';

import { useMemo, useState } from 'react';
import { supabase } from '@/lib/supabase';

type Platform = 'TikTok' | 'YouTube' | 'Facebook';
type Voice = 'Thina' | 'Nilar';

export default function Home() {
  const [platform, setPlatform] = useState<Platform>('TikTok');
  const [voice, setVoice] = useState<Voice>('Thina');
  const [speed, setSpeed] = useState(40);
  const [language, setLanguage] = useState('မြန်မာ');
  const [movie, setMovie] = useState('');
  const [notes, setNotes] = useState('');
  const [duration, setDuration] = useState('5');
  const [hook, setHook] = useState(true);
  const [captions, setCaptions] = useState(true);
  const [watermark, setWatermark] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [script, setScript] = useState('');
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');

  const fileSize = useMemo(() => file ? `${(file.size / 1024 / 1024).toFixed(1)} MB` : '', [file]);

  async function generate() {
    if (!movie.trim()) { setMessage('Movie နာမည် (သို့) ဇာတ်လမ်းအကြောင်း ထည့်ပေးပါ။'); return; }
    setBusy(true); setMessage('AI က Recap Script ရေးပေးနေပါတယ်…'); setScript('');
    try {
      const response = await fetch('/api/generate', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ movie, notes, platform, language, duration, voice, speed, hook, captions })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Script ထုတ်မရပါ။');
      setScript(data.script);
      setMessage('Script အောင်မြင်စွာ ထုတ်ပြီးပါပြီ။');
      if (supabase) {
        await supabase.from('recap_jobs').insert({ movie_title: movie, platform, language, script: data.script, status: 'script_ready' });
      }
    } catch (e) {
      setMessage(e instanceof Error ? e.message : 'မမျှော်လင့်ထားသော Error ဖြစ်နေပါတယ်။');
    } finally { setBusy(false); }
  }

  async function uploadFile() {
    if (!file) { setMessage('Upload လုပ်မယ့် Video ကို ရွေးပါ။'); return; }
    if (!supabase) { setMessage('Video သိမ်းရန် Supabase ချိတ်ဆက်ပါ။ ယခုအချိန်မှာ File ကို ရွေးထားနိုင်ပါတယ်။'); return; }
    setBusy(true); setMessage('Video Upload လုပ်နေပါတယ်…');
    try {
      const safeName = `${Date.now()}-${file.name.replace(/[^a-zA-Z0-9._-]/g, '-')}`;
      const { error } = await supabase.storage.from('source-videos').upload(safeName, file, { upsert: false });
      if (error) throw error;
      setMessage(`Upload ပြီးပါပြီ — ${safeName}`);
    } catch (e) { setMessage(e instanceof Error ? e.message : 'Upload မအောင်မြင်ပါ။'); }
    finally { setBusy(false); }
  }

  async function copyScript() {
    if (!script) return;
    await navigator.clipboard.writeText(script);
    setMessage('Script ကို Copy လုပ်ပြီးပါပြီ။');
  }

  return <main className="shell">
    <header className="topbar"><div className="brand"><span className="mascot">🐻</span><b>Cappy Studio</b><span className="beta">BETA</span></div><div className="topright"><button className="lang active">မြန်မာ</button><button className="lang" onClick={() => setLanguage('English')}>EN</button><span className="credits">🟤 10 credits</span></div></header>
    <div className="pagehead"><div><div className="eyebrow">AI VIDEO WORKSPACE</div><h1>Movie Recap Studio</h1><p>မိမိ Movie ကို Short-form Recap အဖြစ် ပြင်ဆင်ပါ</p></div><div className="avatar">🐻</div></div>

    <section className="panel"><div className="section-title"><span className="ico">▣</span><div><h2>ဘယ် Platform အတွက် ဖန်တီးမလဲ?</h2><p>သင့် Video တင်မယ့် Platform ကို ရွေးချယ်ပါ။</p></div></div><div className="platforms">{(['TikTok','YouTube','Facebook'] as Platform[]).map((p) => <button key={p} className={`platform ${platform===p?'selected':''}`} onClick={()=>setPlatform(p)}><span className="platform-icon">{p==='TikTok'?'▯':p==='YouTube'?'▭':'▯▭'}</span><b>{p}</b><small>{p==='TikTok'?'Reels · Shorts':p==='YouTube'?'YouTube video':'Facebook video'}</small></button>)}</div></section>

    <section className="panel"><div className="section-title"><span className="ico">♬</span><div><h2>အသံ (Voice)</h2><p>AI Voice ရွေးချယ်ရန်။ (ဒီ Starter မှာ Voice preview သာ UI အဖြစ် ပါဝင်သေးသည်)</p></div></div><div className="voices">{(['Thina','Nilar'] as Voice[]).map(v=><button key={v} className={`voice ${voice===v?'selected':''}`} onClick={()=>setVoice(v)}><span>♙</span><span><b>{v==='Thina'?'အမျိုးသမီး':'အမျိုးသမီး'} — {v}</b><small>{v}</small></span><span className="play">▶</span></button>)}</div><div className="range-head"><b>အသံမြန်နှုန်း</b><span>{speed}%</span></div><input aria-label="အသံမြန်နှုန်း" type="range" min="20" max="80" value={speed} onChange={e=>setSpeed(Number(e.target.value))}/></section>

    <section className="panel"><div className="section-title"><span className="ico">✧</span><div><h2>ဗီဒီယို ဖန်တီးမှု Setting</h2><p>Recap အတွက် အောက်ပါအချက်အလက်များကို ပြင်ဆင်ပါ။</p></div></div>
      <div className="formgrid"><label className="field full"><span>Movie နာမည် / ဇာတ်လမ်းအကြောင်း</span><input value={movie} onChange={e=>setMovie(e.target.value)} placeholder="ဥပမာ — Interstellar (သို့) ဇာတ်လမ်းအကျဉ်း"/></label>
      <label className="field"><span>Output Language</span><select value={language} onChange={e=>setLanguage(e.target.value)}><option>မြန်မာ</option><option>English</option></select></label>
      <label className="field"><span>Video Duration (မိနစ်)</span><select value={duration} onChange={e=>setDuration(e.target.value)}><option value="1">1 မိနစ်</option><option value="3">3 မိနစ်</option><option value="5">5 မိနစ်</option><option value="8">8 မိနစ်</option><option value="10">10 မိနစ်</option></select></label>
      <label className="field full"><span>ထပ်ဖြည့်လိုသော အချက်အလက် (Optional)</span><textarea rows={3} value={notes} onChange={e=>setNotes(e.target.value)} placeholder="ဇာတ်လမ်းရဲ့ အဓိကအပိုင်း၊ Spoiler ပါ/မပါ စသည်…"/></label></div>
      <div className="toggles"><label><span><b>အစပိုင်း Hook ထည့်မည်</b><small>ကြည့်ရှုသူ စိတ်ဝင်စားစေမည့် အဖွင့်စာသား</small></span><input type="checkbox" checked={hook} onChange={e=>setHook(e.target.checked)}/></label><label><span><b>Subtitle အတွက် စာသားပြင်ဆင်မည်</b><small>စာကြောင်းတိုများဖြင့် ခွဲပေးမည်</small></span><input type="checkbox" checked={captions} onChange={e=>setCaptions(e.target.checked)}/></label><label><span><b>Watermark စာသား</b><small>Video မှာ ထည့်လိုသည့် Page နာမည်</small></span><input className="watermark" value={watermark} onChange={e=>setWatermark(e.target.value)} placeholder="@MyPage"/></label></div>
    </section>

    <section className="panel"><div className="section-title"><span className="ico">⬆</span><div><h2>Movie Video Upload</h2><p>ဖုန်းထဲမှ Video ရွေးချယ်ပါ။ (Supabase ချိတ်ဆက်ပြီးမှ Cloud Upload အလုပ်လုပ်မည်)</p></div></div><label className="upload"><input type="file" accept="video/*" onChange={e=>setFile(e.target.files?.[0] || null)}/><span className="uploadicon">⬆</span><b>{file ? file.name : 'Video ရွေးချယ်ရန်'}</b><small>{file ? fileSize : 'MP4, MOV, WebM · File size limit depends on storage plan'}</small></label><button className="secondary fullbtn" onClick={uploadFile} disabled={busy || !file}>Cloud Upload</button></section>

    <section className="panel"><div className="section-title"><span className="ico">✦</span><div><h2>AI Recap Generator</h2><p>Movie အကြောင်းအရာမှ Recap Script ထုတ်ပေးမည်။</p></div></div><button className="primary fullbtn" onClick={generate} disabled={busy}>{busy?'လုပ်ဆောင်နေသည်…':'✦  AI Recap Script ထုတ်မည်'}</button>{message && <p className="status">{message}</p>}{script && <div className="result"><div className="resulthead"><b>Generated Recap Script</b><button className="copy" onClick={copyScript}>▣ Copy</button></div><pre>{script}</pre></div>}</section>

    <section className="panel roadmap"><h2>နောက်ထပ်ချိတ်ဆက်ရမည့် Features</h2><div className="roadmaprow"><span>01</span><div><b>AI Voiceover</b><small>Text-to-Speech provider API လိုအပ်သည်</small></div><em>Next</em></div><div className="roadmaprow"><span>02</span><div><b>Auto Subtitle + Video Render</b><small>FFmpeg worker / rendering server လိုအပ်သည်</small></div><em>Next</em></div><div className="roadmaprow"><span>03</span><div><b>Job History, Login, Credits</b><small>Supabase Auth + Database</small></div><em>Next</em></div></section>
    <footer>© 2026 Cappy Studio · Free-first starter · Mobile workspace</footer>
    <div className="bottombar"><span>AI Recap Workspace</span><button onClick={generate} disabled={busy}>စတင်ဖန်တီးမည်</button></div>
  </main>;
}
