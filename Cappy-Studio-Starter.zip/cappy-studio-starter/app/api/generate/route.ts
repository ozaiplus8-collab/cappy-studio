import { NextRequest, NextResponse } from 'next/server';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  try {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) return NextResponse.json({ error: 'GEMINI_API_KEY မထည့်ရသေးပါ။ .env.local ထဲတွင် API key ထည့်ပါ။' }, { status: 503 });
    const body = await req.json();
    const { movie, notes = '', platform = 'TikTok', language = 'မြန်မာ', duration = '5', hook = true, captions = true } = body;
    if (typeof movie !== 'string' || !movie.trim()) return NextResponse.json({ error: 'Movie နာမည် ထည့်ပေးပါ။' }, { status: 400 });

    const prompt = `You are a careful movie recap scriptwriter. Create an original, concise recap narration based on the user's supplied movie title/context. Do not reproduce dialogue or long copyrighted passages. Do not claim scene-by-scene visual analysis if no video was supplied. If the title is ambiguous or you lack reliable plot knowledge, ask for a synopsis rather than inventing events.\nLanguage: ${language}. Platform: ${platform}. Target duration: ${duration} minutes. Include opening hook: ${hook}. Format subtitle-friendly short paragraphs: ${captions}. Additional user notes: ${notes || 'None'}. Movie/title/context: ${movie}.\nOutput: title, hook (if enabled), narration in coherent chronological order, and a short ending/CTA. Avoid fabricated facts.`;

    const model = process.env.GEMINI_MODEL || 'gemini-2.0-flash';
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }], generationConfig: { temperature: 0.7, maxOutputTokens: 5000 } })
    });
    const data = await response.json();
    if (!response.ok) return NextResponse.json({ error: data?.error?.message || 'Gemini API request failed.' }, { status: response.status });
    const script = data?.candidates?.[0]?.content?.parts?.map((p: { text?: string }) => p.text || '').join('\n').trim();
    if (!script) return NextResponse.json({ error: 'AI က စာသားပြန်မပေးနိုင်ပါ။ နောက်တစ်ကြိမ် စမ်းကြည့်ပါ။' }, { status: 502 });
    return NextResponse.json({ script });
  } catch {
    return NextResponse.json({ error: 'Request မအောင်မြင်ပါ။ Input ကို ပြန်စစ်ပါ။' }, { status: 500 });
  }
}
